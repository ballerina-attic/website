Description
===========
This example explains how to create and use WebSocket client connector in ballerina.

How to run the sample
=====================
bin$ ./ballerina run ../samples/websocket/clientsample/webSocketClientSample.balx

How to connect
==============
Connect to ws://localhost:9090/pass-through/ws using any WebSocket client and send messages to check
