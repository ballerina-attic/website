Description
===========
These samples will illustrate usage of transform statement to transform structs and JSONs constrained by structs.

How to run this sample
======================
bin$ ./ballerina run ../samples/transformStmt/StructTransform.bal
bin$ ./ballerina run ../samples/transformStmt/JSONTransform.bal
